const CACHE='qoa-v8-0-2-r3';
const ASSETS=[
  './','./index.html','./manifest.webmanifest','./assets/app-icon.png','./assets/jszip.min.js','./assets/offline-xlsx.js',
  './assets/products/cable.svg','./assets/products/nails.svg','./assets/products/pipe.svg','./assets/products/tape.svg',
  './assets/products/sealant.svg','./assets/products/roller.svg','./assets/products/hose.svg','./assets/products/screws.svg',
  './assets/products/paint.svg','./assets/products/tools.svg'
];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  if(e.request.method!=='GET') return;
  e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request).then(r=>{let copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return r;}).catch(()=>e.request.mode==='navigate'?caches.match('./index.html'):undefined)));
});
