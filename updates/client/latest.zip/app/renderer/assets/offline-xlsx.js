(function(global){
  'use strict';
  function textOf(node){
    if(!node) return '';
    return Array.from(node.getElementsByTagName('t')).map(t=>t.textContent||'').join('');
  }
  function colIndex(ref){
    var m=String(ref||'').match(/^([A-Z]+)/i); if(!m) return 0;
    var s=m[1].toUpperCase(), n=0; for(var i=0;i<s.length;i++) n=n*26+(s.charCodeAt(i)-64); return n-1;
  }
  function parseXml(str){ return new DOMParser().parseFromString(str,'application/xml'); }
  async function loadText(zip,path){ var f=zip.file(path); return f?await f.async('string'):''; }
  async function readXlsxOffline(buffer){
    if(!global.JSZip) throw new Error('Offline Excel moduli topilmadi.');
    var zip=await global.JSZip.loadAsync(buffer);
    var shared=[];
    var ss=await loadText(zip,'xl/sharedStrings.xml');
    if(ss){ var sdoc=parseXml(ss); shared=Array.from(sdoc.getElementsByTagName('si')).map(textOf); }
    var wbXml=await loadText(zip,'xl/workbook.xml');
    if(!wbXml) throw new Error('Excel workbook topilmadi. Fayl .xlsx formatida ekanini tekshiring.');
    var wb=parseXml(wbXml), sheet=wb.getElementsByTagName('sheet')[0];
    if(!sheet) return [];
    var rid=sheet.getAttribute('r:id')||sheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
    var relXml=await loadText(zip,'xl/_rels/workbook.xml.rels'), target='worksheets/sheet1.xml';
    if(relXml && rid){
      var rel=parseXml(relXml); Array.from(rel.getElementsByTagName('Relationship')).some(function(x){ if(x.getAttribute('Id')===rid){ target=x.getAttribute('Target')||target; return true; } return false; });
    }
    target=target.replace(/^\//,''); if(!target.startsWith('xl/')) target='xl/'+target.replace(/^\.\//,'');
    var sx=await loadText(zip,target); if(!sx) sx=await loadText(zip,'xl/worksheets/sheet1.xml');
    if(!sx) throw new Error('Excel varaqi o‘qilmadi.');
    var doc=parseXml(sx), rows=[];
    Array.from(doc.getElementsByTagName('row')).forEach(function(row){
      var arr=[];
      Array.from(row.getElementsByTagName('c')).forEach(function(c){
        var idx=colIndex(c.getAttribute('r')), type=c.getAttribute('t')||'', v='';
        if(type==='inlineStr') v=textOf(c);
        else { var vn=c.getElementsByTagName('v')[0]; v=vn?vn.textContent:''; if(type==='s') v=shared[Number(v)]??''; else if(type==='b') v=(v==='1'); else if(type!=='str' && v!=='' && !isNaN(v)) v=Number(v); }
        arr[idx]=v;
      });
      rows.push(arr);
    });
    var headerIndex=rows.findIndex(function(r){return r.some(function(x){return String(x??'').trim()!=='';});});
    if(headerIndex<0) return [];
    var headers=rows[headerIndex].map(function(h,i){ var x=String(h??'').trim(); return x||('column_'+(i+1)); });
    var out=[];
    for(var r=headerIndex+1;r<rows.length;r++){
      if(!rows[r].some(function(x){return String(x??'').trim()!=='';})) continue;
      var o={}; headers.forEach(function(h,i){o[h]=rows[r][i]??'';}); out.push(o);
    }
    return out;
  }
  global.readXlsxOffline=readXlsxOffline;
})(window);
