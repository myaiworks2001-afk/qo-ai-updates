const { app, BrowserWindow, ipcMain, dialog, net, shell, session } = require('electron');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { pathToFileURL } = require('url');

const APP_VERSION = '8.2.6-r7.0';
app.setName('Qurilish Ombori AI');
const EDITION='owner';
if(process.platform==='win32') app.setAppUserModelId('QO.QurilishOmboriAI');
let mainWindow = null;
let config = null;
let syncTimer = null;
let lastRendererState = null;
let lastInternetCheckAt = 0;
let lastInternetResult = false;

function safeReadJson(file, fallback=null){
  try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch { return fallback; }
}
function ensureDir(p){ fs.mkdirSync(p,{recursive:true}); return p; }
function atomicWriteJson(file, data){
  ensureDir(path.dirname(file));
  const tmp = file + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(data,null,2),'utf8');
  fs.renameSync(tmp,file);
}
function cfgPath(){ return path.join(app.getPath('userData'),'desktop-config.json'); }
function dataDir(){ return ensureDir(path.join(app.getPath('userData'),'data')); }
function localStatePath(){ return path.join(dataDir(),'state.json'); }
function auditPath(){ return path.join(dataDir(),'audit.log'); }
function imageCacheDir(){ return ensureDir(path.join(app.getPath('userData'),'image-cache')); }
function catalogImageDir(){ const r=driveRoot(); return r?ensureDir(path.join(r,'catalog','images')):null; }
function loadConfig(){
  const c=safeReadJson(cfgPath(),{});
  if(!c.clientId) c.clientId='QO-'+crypto.randomUUID().slice(0,8).toUpperCase();
  if(!c.installId) c.installId=crypto.randomUUID();
  if(!c.deviceName) c.deviceName=os.hostname();
  if(!c.syncIntervalSec) c.syncIntervalSec=30;
  config=c; saveConfig(); return c;
}
function saveConfig(){ atomicWriteJson(cfgPath(),config||{}); }
function audit(type, detail={}){
  const line=JSON.stringify({ts:new Date().toISOString(),type,clientId:config?.clientId,device:os.hostname(),...detail})+'\n';
  fs.appendFileSync(auditPath(),line,'utf8');
}
function driveRoot(){ return config?.drivePath ? path.join(config.drivePath,'QO_AI_CLOUD') : null; }
function clientCloudDir(id=config?.clientId){ const r=driveRoot(); return r?path.join(r,'clients',id):null; }
function ownerControlDir(id=config?.clientId){ const r=driveRoot(); return r?path.join(r,'control',id):null; }
function updateDir(){ const r=driveRoot(); return r?path.join(r,'updates'):null; }
function updateChannelDir(target='client'){ const u=updateDir(); return u?path.join(u,String(target||'client').toLowerCase()):null; }
function updateManifestPath(target='client'){ const d=updateChannelDir(target); return d?path.join(d,'manifest.json'):null; }
function normalizeUpdateTarget(v){ const t=String(v||'client').toLowerCase(); return ['client','owner','all'].includes(t)?t:'client'; }
function copyIfExists(src,dst){ if(!src||!dst||!fs.existsSync(src))return false; ensureDir(path.dirname(dst)); fs.copyFileSync(src,dst); return true; }
function ensureUpdateLayout(){
  if(!cloudReachable()) return;
  const u=ensureDir(updateDir()); ensureDir(updateChannelDir('client')); ensureDir(updateChannelDir('owner'));
  const legacy=safeReadJson(path.join(u,'manifest.json'),null);
  if(!legacy?.version||!legacy?.file)return;
  const target=normalizeUpdateTarget(legacy.target||'client');
  const migrate=(ch)=>{
    const mf=updateManifestPath(ch);
    if(fs.existsSync(mf))return;
    const src=path.join(u,legacy.file), dst=path.join(updateChannelDir(ch),legacy.file);
    if(fs.existsSync(src))copyIfExists(src,dst);
    atomicWriteJson(mf,{...legacy,target:ch,migratedFromLegacy:true,migratedAt:new Date().toISOString()});
  };
  if(target==='client'||target==='all')migrate('client');
  if(target==='owner'||target==='all')migrate('owner');
}
function readUpdateManifest(target='client'){
  if(!cloudReachable())return null; ensureUpdateLayout();
  const ch=normalizeUpdateTarget(target)==='owner'?'owner':'client', dir=updateChannelDir(ch);
  let m=safeReadJson(path.join(dir,'manifest.json'),null);
  if(m?.version&&m?.file)return {...m,_source:'channel',_sourceDir:dir};
  const u=updateDir(),legacy=safeReadJson(path.join(u,'manifest.json'),null),lt=normalizeUpdateTarget(legacy?.target||'client');
  if(legacy?.version&&legacy?.file&&((ch==='client'&&(lt==='client'||lt==='all'))||(ch==='owner'&&(lt==='owner'||lt==='all'))))return {...legacy,_source:'legacy',_sourceDir:u};
  return null;
}
function cloudConfigured(){ return !!(config?.drivePath); }
function cloudReachable(){ try{return cloudConfigured() && fs.existsSync(config.drivePath) && fs.statSync(config.drivePath).isDirectory();}catch{return false;} }

function serviceConfigured(){ return !!(config?.serviceUrl && config?.serviceSecret); }
async function servicePost(action,payload={}){
  if(!serviceConfigured()) return {ok:false,error:'QO Service ulanmagan'};
  const ctrl=new AbortController(); const tm=setTimeout(()=>ctrl.abort(),5000);
  try{
    const res=await net.fetch(config.serviceUrl,{method:'POST',headers:{'content-type':'application/json'},signal:ctrl.signal,body:JSON.stringify({action,secret:config.serviceSecret,clientId:config.clientId,installId:config.installId,device:os.hostname(),appVersion:APP_VERSION,payload})});
    const txt=await res.text(); let data={}; try{data=JSON.parse(txt)}catch{data={ok:false,error:txt.slice(0,400)}}
    if(!res.ok && data.ok!==false) data={ok:false,error:'HTTP '+res.status}; return data;
  }catch(e){ return {ok:false,error:e.message}; } finally{clearTimeout(tm)}
}

async function internetCheck(force=false){
  const now=Date.now();
  if(!force && now-lastInternetCheckAt<20000) return lastInternetResult;
  const ctrl = new AbortController();
  const t=setTimeout(()=>ctrl.abort(),1800);
  try{
    const r=await net.fetch('https://www.google.com/generate_204',{signal:ctrl.signal,cache:'no-store'});
    lastInternetResult = r.status>=200 && r.status<500;
  }catch{ lastInternetResult=false; }
  finally{ clearTimeout(t); lastInternetCheckAt=Date.now(); }
  return lastInternetResult;
}
function readCloudControl(){
  const fallback=config?.lastLicense||{status:'active',until:null,note:'Drive test mode'};
  const out={license:{...fallback},commands:[],update:null};
  if(cloudReachable()){
    const cdir=ownerControlDir();
    out.license=safeReadJson(path.join(cdir,'license.json'),out.license)||out.license;
    const cq=safeReadJson(path.join(cdir,'commands.json'),{commands:[]})||{commands:[]};
    out.commands=Array.isArray(cq.commands)?cq.commands:[];
    // OWNER faqat OWNER kanalini ko'radi. CLIENT manifesti OWNER upgrade badge'iga chiqmaydi.
    out.update=readUpdateManifest('owner');
    config.lastLicense=out.license; config.lastOwnerUpdate=out.update?{...out.update,_sourceDir:undefined}:null; saveConfig();
  }
  if(out.license?.until){
    const exp=Date.parse(out.license.until+'T23:59:59');
    if(Number.isFinite(exp)&&Date.now()>exp&&out.license.status==='active') out.license={...out.license,status:'read_only',note:(out.license.note||'')+' · expired'};
  }
  return out;
}
function fileSha256(file){ try{return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}catch{return ''} }
function updateChannelStatus(target='client',verifyHash=false){
  const ch=target==='owner'?'owner':'client';
  if(!cloudReachable())return {target:ch,configured:false,manifest:null,packageExists:false,hashOk:null,error:'Drive ulanmagan'};
  ensureUpdateLayout();
  const dir=updateChannelDir(ch), mf=path.join(dir,'manifest.json'), manifest=safeReadJson(mf,null);
  if(!manifest?.version||!manifest?.file)return {target:ch,configured:true,manifest:null,manifestPath:mf,packageExists:false,hashOk:null,error:null};
  const file=path.join(dir,manifest.file), exists=fs.existsSync(file);
  let hashOk=null,actualSha256='';
  if(exists&&verifyHash&&manifest.sha256){actualSha256=fileSha256(file);hashOk=actualSha256===manifest.sha256}
  let stat=null; try{stat=exists?fs.statSync(file):null}catch{}
  return {target:ch,configured:true,manifest:{...manifest},manifestPath:mf,packagePath:file,packageExists:exists,packageBytes:stat?.size||0,hashOk,actualSha256,error:exists?null:'Paket fayli topilmadi'};
}
function legacyUpdateStatus(verifyHash=false){
  if(!cloudReachable())return {manifest:null,packageExists:false,hashOk:null};
  const dir=updateDir(), mf=path.join(dir,'manifest.json'), manifest=safeReadJson(mf,null);
  if(!manifest?.version||!manifest?.file)return {manifest:null,manifestPath:mf,packageExists:false,hashOk:null};
  const file=path.join(dir,manifest.file),exists=fs.existsSync(file);let actualSha256='',hashOk=null;
  if(exists&&verifyHash&&manifest.sha256){actualSha256=fileSha256(file);hashOk=actualSha256===manifest.sha256}
  let stat=null;try{stat=exists?fs.statSync(file):null}catch{}
  return {manifest:{...manifest},manifestPath:mf,packagePath:file,packageExists:exists,packageBytes:stat?.size||0,hashOk,actualSha256};
}
async function updateCenterStatus(verifyHash=false){
  const clients=[];
  if(cloudReachable()){
    const root=ensureDir(path.join(driveRoot(),'clients')); let dirs=[];try{dirs=(await fsp.readdir(root,{withFileTypes:true})).filter(x=>x.isDirectory())}catch{}
    for(const d of dirs){const hb=safeReadJson(path.join(root,d.name,'heartbeat.json'),null);if(hb)clients.push({clientId:d.name,...hb})}
  }
  clients.sort((a,b)=>String(b.lastSeen||'').localeCompare(String(a.lastSeen||'')));
  return {
    appVersion:APP_VERSION,edition:EDITION,driveConfigured:cloudConfigured(),driveReachable:cloudReachable(),drivePath:config?.drivePath||'',
    client:updateChannelStatus('client',verifyHash),owner:updateChannelStatus('owner',verifyHash),legacy:legacyUpdateStatus(verifyHash),
    clients:{count:clients.length,latest:clients[0]||null,items:clients.slice(0,20)},checkedAt:new Date().toISOString()
  };
}

// --- R6.5 Simple Public Update Channel (GitHub, no Apps Script) ---
function parsePublicRepo(value){
  let s=String(value||'').trim();
  s=s.replace(/^https?:\/\/github\.com\//i,'').replace(/^github\.com\//i,'').replace(/\.git$/i,'').replace(/^\/+|\/+$/g,'');
  const parts=s.split('/').filter(Boolean);
  if(parts.length<2)return null;
  const owner=parts[0],repo=parts[1];
  if(!/^[A-Za-z0-9_.-]+$/.test(owner)||!/^[A-Za-z0-9_.-]+$/.test(repo))return null;
  return {owner,repo,slug:owner+'/'+repo,url:'https://github.com/'+owner+'/'+repo};
}
function publicBranch(){return String(config?.publicUpdateBranch||'main').trim()||'main'}
function publicRepo(){return parsePublicRepo(config?.publicUpdateRepo||'')}
function publicChannelConfigured(){return !!publicRepo()}
function publicPublisherConfigured(){return !!(publicRepo()&&config?.publicUpdateToken)}
function rawPublicUrl(target,file){const r=publicRepo();if(!r)return '';return `https://raw.githubusercontent.com/${r.owner}/${r.repo}/${publicBranch()}/updates/${target}/${file}`}
async function fetchWithTimeout(url,opts={},ms=12000){
  const ctrl=new AbortController();const tm=setTimeout(()=>ctrl.abort(),ms);
  try{return await net.fetch(url,{...opts,signal:ctrl.signal,cache:'no-store'})}finally{clearTimeout(tm)}
}
async function publicUpdateStatus(target='client'){
  const ch=target==='owner'?'owner':'client', repo=publicRepo(), checkedAt=new Date().toISOString();
  if(!repo)return {target:ch,configured:false,reachable:false,manifest:null,error:'Public update kanali sozlanmagan',checkedAt};
  const manifestUrl=rawPublicUrl(ch,'manifest.json')+'?t='+Date.now();
  try{
    const res=await fetchWithTimeout(manifestUrl,{headers:{'user-agent':'QO-AI-Desktop'}},9000);
    if(res.status===404)return {target:ch,configured:true,reachable:true,manifest:null,error:null,repo:repo.slug,branch:publicBranch(),manifestUrl,checkedAt};
    if(!res.ok)return {target:ch,configured:true,reachable:false,manifest:null,error:'HTTP '+res.status,repo:repo.slug,branch:publicBranch(),manifestUrl,checkedAt};
    const txt=await res.text();let m=null;try{m=JSON.parse(txt)}catch{return {target:ch,configured:true,reachable:false,manifest:null,error:'manifest.json noto‘g‘ri JSON',repo:repo.slug,branch:publicBranch(),manifestUrl,checkedAt}}
    const mt=String(m?.target||ch).toLowerCase();if(m?.version&&mt!==ch&&mt!=='all')return {target:ch,configured:true,reachable:false,manifest:null,error:`Manifest target=${mt}; ${ch} kutilgan`,repo:repo.slug,branch:publicBranch(),manifestUrl,checkedAt};
    return {target:ch,configured:true,reachable:true,manifest:m?.version?m:null,error:null,repo:repo.slug,branch:publicBranch(),manifestUrl,packageUrl:m?.file?rawPublicUrl(ch,m.file):'',checkedAt};
  }catch(e){return {target:ch,configured:true,reachable:false,manifest:null,error:e.name==='AbortError'?'Ulanish vaqti tugadi':e.message,repo:repo.slug,branch:publicBranch(),manifestUrl,checkedAt}}
}
async function githubApi(method,endpoint,body=null){
  const token=String(config?.publicUpdateToken||'').trim();if(!token)throw new Error('GitHub token kiritilmagan');
  const headers={'accept':'application/vnd.github+json','authorization':'Bearer '+token,'x-github-api-version':'2022-11-28','user-agent':'QO-AI-Owner'};
  if(body!==null)headers['content-type']='application/json';
  const r=await fetchWithTimeout('https://api.github.com'+endpoint,{method,headers,body:body===null?undefined:JSON.stringify(body)},20000);
  const txt=await r.text();let data={};try{data=txt?JSON.parse(txt):{}}catch{data={message:txt.slice(0,500)}}
  if(!r.ok){const err=new Error(data.message||('GitHub HTTP '+r.status));err.status=r.status;throw err}return data;
}
async function githubExistingSha(repo,pathName){
  try{const x=await githubApi('GET',`/repos/${repo.owner}/${repo.repo}/contents/${pathName}?ref=${encodeURIComponent(publicBranch())}`);return x?.sha||null}catch(e){if(e.status===404)return null;throw e}
}
async function githubPut(repo,pathName,buf,message){
  const sha=await githubExistingSha(repo,pathName);const body={message,content:Buffer.from(buf).toString('base64'),branch:publicBranch()};if(sha)body.sha=sha;
  return githubApi('PUT',`/repos/${repo.owner}/${repo.repo}/contents/${pathName}`,body);
}
async function publishPublicUpdate(p={}){
  const repo=publicRepo();if(!repo)return {ok:false,error:'GitHub repository sozlanmagan'};if(!config?.publicUpdateToken)return {ok:false,error:'GitHub token kiritilmagan'};
  if(!p.packagePath||!fs.existsSync(p.packagePath))return {ok:false,error:'Update ZIP topilmadi'};
  const version=String(p.version||'').trim();if(!version)return {ok:false,error:'Versiyani kiriting'};
  const target=normalizeUpdateTarget(p.target||'client'),source=await fsp.readFile(p.packagePath),hash=crypto.createHash('sha256').update(source).digest('hex'),publishedAt=new Date().toISOString();
  const publishOne=async ch=>{
    const zipPath=`updates/${ch}/latest.zip`,manifestPath=`updates/${ch}/manifest.json`;
    await githubPut(repo,zipPath,source,`QO ${ch} ${version}: package`);
    const manifest={version,notes:p.notes||'',file:'latest.zip',sha256:hash,publishedAt,channel:p.channel||'stable',target:ch,format:3,transport:'github-public',repository:repo.slug,branch:publicBranch()};
    await githubPut(repo,manifestPath,Buffer.from(JSON.stringify(manifest,null,2)+'\n','utf8'),`QO ${ch} ${version}: manifest`);
    return {manifest,path:manifestPath};
  };
  let client=null,owner=null;try{if(target==='client'||target==='all')client=await publishOne('client');if(target==='owner'||target==='all')owner=await publishOne('owner')}catch(e){return {ok:false,error:e.message||String(e)}}
  audit('public_update_published',{version,target,sha256:hash,repo:repo.slug});return {ok:true,version,target,sha256:hash,repo:repo.slug,client,owner};
}
async function downloadAndApplyPublicUpdate(target='owner'){
  const ch=target==='client'?'client':'owner',st=await publicUpdateStatus(ch),m=st.manifest;
  if(!st.configured)return {ok:false,error:'Update kanali sozlanmagan'};if(!st.reachable)return {ok:false,error:st.error||'Update kanaliga ulanib bo‘lmadi'};if(!m?.version||!m?.file)return {ok:false,error:'Update manifest topilmadi'};
  const mt=String(m.target||ch).toLowerCase();if(mt!==ch&&mt!=='all')return {ok:false,error:`Bu update ${ch.toUpperCase()} uchun emas`};
  try{
    const res=await fetchWithTimeout(rawPublicUrl(ch,m.file)+'?t='+Date.now(),{headers:{'user-agent':'QO-AI-Desktop'}},30000);if(!res.ok)return {ok:false,error:'Update ZIP HTTP '+res.status};
    const buf=Buffer.from(await res.arrayBuffer()),hash=crypto.createHash('sha256').update(buf).digest('hex');if(m.sha256&&hash!==m.sha256)return {ok:false,error:'Update SHA-256 mos emas'};
    const zipPath=path.join(app.getPath('temp'),`qo-public-${ch}-${Date.now()}.zip`);await fsp.writeFile(zipPath,buf);
    const appPath=app.getAppPath(),tmp=path.join(app.getPath('temp'),'QOAI_PUBLIC_UPDATE_'+Date.now()),backup=path.join(app.getPath('userData'),'update-backup-'+ch),script=path.join(app.getPath('temp'),'qoai_apply_public_update_'+Date.now()+'.cmd');ensureDir(tmp);
    const content=`@echo off\r\nchcp 65001>nul\r\ntimeout /t 2 /nobreak>nul\r\nif exist "${tmp}" rmdir /s /q "${tmp}"\r\nmkdir "${tmp}"\r\npowershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${zipPath.replace(/'/g,"''")}' -DestinationPath '${tmp.replace(/'/g,"''")}' -Force"\r\nif errorlevel 1 exit /b 1\r\nif not exist "${path.join(tmp,'app','main.js')}" exit /b 2\r\nif exist "${backup}" rmdir /s /q "${backup}"\r\nmkdir "${backup}"\r\nxcopy /E /I /Y "${path.join(appPath,'*')}" "${backup}\\" >nul\r\nxcopy /E /I /Y "${path.join(tmp,'app','*')}" "${appPath}\\" >nul\r\nstart "" "${process.execPath}"\r\n`;
    fs.writeFileSync(script,content,'utf8');audit('public_update_install_requested',{version:m.version,target:ch,repo:st.repo});spawn('cmd.exe',['/c','start','',script],{detached:true,stdio:'ignore'}).unref();setTimeout(()=>app.quit(),500);return {ok:true,version:m.version};
  }catch(e){return {ok:false,error:e.message||String(e)}}
}


function clearProcessedCommands(ids=[]){
  if(!cloudReachable()||!ids.length) return;
  const p=path.join(ownerControlDir(),'commands.json');
  const q=safeReadJson(p,{commands:[]})||{commands:[]};
  q.commands=(q.commands||[]).filter(x=>!ids.includes(x.id));
  atomicWriteJson(p,q);
}
async function writeCloudSnapshot(state){
  if(!cloudReachable()) return false;
  const d=clientCloudDir(); ensureDir(d);
  atomicWriteJson(path.join(d,'snapshot.json'),{appVersion:APP_VERSION,savedAt:new Date().toISOString(),clientId:config.clientId,device:os.hostname(),state});
  atomicWriteJson(path.join(d,'heartbeat.json'),{clientId:config.clientId,installId:config.installId,device:os.hostname(),appVersion:APP_VERSION,lastSeen:new Date().toISOString(),platform:process.platform,arch:process.arch});
  config.lastSyncAt=new Date().toISOString(); saveConfig();
  return true;
}
function persistLocalState(state){
  lastRendererState=state;
  atomicWriteJson(localStatePath(),{savedAt:new Date().toISOString(),appVersion:APP_VERSION,state});
}
function debounceCloudSync(){
  clearTimeout(syncTimer);
  syncTimer=setTimeout(async()=>{
    if(lastRendererState){ try{ await writeCloudSnapshot(lastRendererState); }catch(e){ audit('sync_error',{message:e.message}); } }
  },5000);
}


function safeFileStem(s='image'){
  return String(s||'image').normalize('NFKD').replace(/[^a-zA-Z0-9._-]+/g,'-').replace(/^-+|-+$/g,'').slice(0,90)||'image';
}
function isImageFile(name=''){ return /\.(png|jpe?g|webp|svg|avif)$/i.test(name); }
async function scanImageLibrary(){
  const cache=imageCacheDir();
  const items=[];
  if(cloudReachable()){
    const srcDir=catalogImageDir();
    let files=[]; try{files=await fsp.readdir(srcDir,{withFileTypes:true});}catch{}
    for(const ent of files){
      if(!ent.isFile()||!isImageFile(ent.name)) continue;
      const src=path.join(srcDir,ent.name), dst=path.join(cache,ent.name);
      try{
        const a=await fsp.stat(src), b=fs.existsSync(dst)?await fsp.stat(dst):null;
        if(!b||a.size!==b.size||Math.abs(a.mtimeMs-b.mtimeMs)>1500) await fsp.copyFile(src,dst);
      }catch{ continue; }
      const stem=path.parse(ent.name).name;
      items.push({key:stem,fileName:ent.name,url:pathToFileURL(dst).href,source:'drive'});
    }
  }else{
    let files=[]; try{files=await fsp.readdir(cache,{withFileTypes:true});}catch{}
    for(const ent of files){if(ent.isFile()&&isImageFile(ent.name)){const stem=path.parse(ent.name).name;items.push({key:stem,fileName:ent.name,url:pathToFileURL(path.join(cache,ent.name)).href,source:'cache'});}}
  }
  return items;
}
async function importProductImage(meta={}){
  const r=await dialog.showOpenDialog(mainWindow,{title:'Mahsulot rasmini tanlang',properties:['openFile'],filters:[{name:'Rasmlar',extensions:['png','jpg','jpeg','webp','svg','avif']}]});
  if(r.canceled||!r.filePaths[0]) return {ok:false};
  const src=r.filePaths[0], ext=path.extname(src).toLowerCase()||'.jpg';
  const base=safeFileStem([meta.sku,meta.name,meta.category].filter(Boolean).join('-'));
  const hash=crypto.createHash('sha1').update(src+Date.now()).digest('hex').slice(0,8);
  const fileName=`${base}-${hash}${ext}`;
  const cacheDest=path.join(imageCacheDir(),fileName);
  await fsp.copyFile(src,cacheDest);
  let driveSaved=false;
  if(cloudReachable()){
    const driveDest=path.join(catalogImageDir(),fileName);
    await fsp.copyFile(src,driveDest); driveSaved=true;
  }
  return {ok:true,item:{key:path.parse(fileName).name,fileName,url:pathToFileURL(cacheDest).href,source:driveSaved?'drive':'cache'},driveSaved};
}



// --- R7.0 Local Voice Engine (Whisper.cpp) ---
const R7_VOICE_ENGINE_VERSION = 'v1.9.2';
const R7_VOICE_BIN_URL = 'https://github.com/ggml-org/whisper.cpp/releases/download/v1.9.2/whisper-bin-x64.zip';
const R7_VOICE_BIN_SHA256 = '49dcc16de826f20bd53d44f947a1ae49dfa81f86cad67a64d80820cb192d674a';
const R7_VOICE_MODEL_URL = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny-q5_1.bin';
const R7_VOICE_MODEL_SHA256 = '818710568da3ca15689e31a743197b520007872ff9576237bda97bd1b469c3d7';
function r7VoiceDir(){ return ensureDir(path.join(app.getPath('userData'),'voice-engine')); }
function r7VoiceMetaPath(){ return path.join(r7VoiceDir(),'engine.json'); }
function r7Sha256(buf){ return crypto.createHash('sha256').update(buf).digest('hex'); }
function r7FindFile(root,name){
  try{for(const e of fs.readdirSync(root,{withFileTypes:true})){const p=path.join(root,e.name);if(e.isFile()&&e.name.toLowerCase()===name.toLowerCase())return p;if(e.isDirectory()){const x=r7FindFile(p,name);if(x)return x}}}catch{}
  return '';
}
async function r7Download(url,timeoutMs=120000){
  const ctrl=new AbortController(), tm=setTimeout(()=>ctrl.abort(),timeoutMs);
  try{const res=await net.fetch(url,{signal:ctrl.signal,cache:'no-store',headers:{'user-agent':'QO-AI-Voice-R7'}});if(!res.ok)throw new Error('HTTP '+res.status+' · '+url);return Buffer.from(await res.arrayBuffer())}finally{clearTimeout(tm)}
}
function r7RunProcess(file,args,opts={}){
  return new Promise((resolve,reject)=>{
    const cp=spawn(file,args,{windowsHide:true,...opts});let stdout='',stderr='';
    cp.stdout?.on('data',d=>stdout+=d.toString('utf8'));cp.stderr?.on('data',d=>stderr+=d.toString('utf8'));
    cp.on('error',reject);cp.on('close',code=>code===0?resolve({code,stdout,stderr}):reject(new Error((stderr||stdout||('Exit '+code)).trim().slice(-1800))));
  });
}
function r7VoiceEngineStatus(){
  const meta=safeReadJson(r7VoiceMetaPath(),{})||{}, exe=meta.exePath||r7FindFile(r7VoiceDir(),'whisper-cli.exe'), model=meta.modelPath||path.join(r7VoiceDir(),'ggml-tiny-q5_1.bin');
  const installed=!!(exe&&fs.existsSync(exe)&&fs.existsSync(model));
  return {ok:true,installed,platform:process.platform,arch:process.arch,engine:'whisper.cpp',engineVersion:R7_VOICE_ENGINE_VERSION,model:'ggml-tiny-q5_1',exePath:installed?exe:'',modelPath:installed?model:'',offlineAfterInstall:true};
}
async function r7InstallVoiceEngine(){
  if(process.platform!=='win32'||process.arch!=='x64')return {ok:false,error:'R7 lokal Voice Engine hozir Windows x64 uchun tayyorlangan.'};
  try{
    const dir=r7VoiceDir(), binZip=path.join(dir,'whisper-bin-x64.zip'), modelPath=path.join(dir,'ggml-tiny-q5_1.bin'), binRoot=path.join(dir,'whisper-bin');
    let exe=r7FindFile(binRoot,'whisper-cli.exe');
    if(!exe||!fs.existsSync(exe)){
      const bin=await r7Download(R7_VOICE_BIN_URL,90000);const hash=r7Sha256(bin);if(hash!==R7_VOICE_BIN_SHA256)throw new Error('Voice Engine SHA-256 mos emas');
      await fsp.writeFile(binZip,bin);try{await fsp.rm(binRoot,{recursive:true,force:true})}catch{}ensureDir(binRoot);
      await r7RunProcess('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-Command',`Expand-Archive -LiteralPath '${binZip.replace(/'/g,"''")}' -DestinationPath '${binRoot.replace(/'/g,"''")}' -Force`]);
      exe=r7FindFile(binRoot,'whisper-cli.exe');if(!exe)throw new Error('whisper-cli.exe arxiv ichidan topilmadi');
      try{await fsp.unlink(binZip)}catch{}
    }
    if(!fs.existsSync(modelPath)){
      const model=await r7Download(R7_VOICE_MODEL_URL,180000);const hash=r7Sha256(model);if(hash!==R7_VOICE_MODEL_SHA256)throw new Error('Voice modeli SHA-256 mos emas');await fsp.writeFile(modelPath,model);
    } else {
      const hash=r7Sha256(await fsp.readFile(modelPath));if(hash!==R7_VOICE_MODEL_SHA256){await fsp.unlink(modelPath);return r7InstallVoiceEngine()}
    }
    atomicWriteJson(r7VoiceMetaPath(),{engine:'whisper.cpp',version:R7_VOICE_ENGINE_VERSION,exePath:exe,modelPath,installedAt:new Date().toISOString(),binSha256:R7_VOICE_BIN_SHA256,modelSha256:R7_VOICE_MODEL_SHA256});
    audit('voice_engine_installed',{engine:'whisper.cpp',version:R7_VOICE_ENGINE_VERSION,model:'ggml-tiny-q5_1'});return r7VoiceEngineStatus();
  }catch(e){audit('voice_engine_install_failed',{error:e.message});return {ok:false,error:e.message||String(e)}}
}
async function r7TranscribeWav(payload={}){
  const st=r7VoiceEngineStatus();if(!st.installed)return {ok:false,error:'Voice Engine o‘rnatilmagan. Sozlamalar → Ovozli sotuv → Voice Engine o‘rnatish.'};
  try{
    let input=payload.audio;if(input?.type==='Buffer'&&Array.isArray(input.data))input=input.data;const buf=Buffer.from(input||[]);if(buf.length<1000)throw new Error('Audio juda qisqa');if(buf.length>24*1024*1024)throw new Error('Audio 24 MB dan katta');
    const wav=path.join(app.getPath('temp'),'qo-r7-voice-'+Date.now()+'.wav');await fsp.writeFile(wav,buf);
    const lang=/^(uz|ru|en)$/.test(String(payload.language||'uz'))?String(payload.language):'uz';
    let result;try{result=await r7RunProcess(st.exePath,['-m',st.modelPath,'-f',wav,'-l',lang,'-nt','-np','-t',String(Math.max(1,Math.min(4,os.cpus()?.length||2)))],{cwd:path.dirname(st.exePath)})}finally{try{await fsp.unlink(wav)}catch{}}
    let text=String(result.stdout||'').trim();if(!text){text=String(result.stderr||'').split(/\r?\n/).filter(x=>x&&!/^(whisper_|main:|system_info|ggml_|load time|encode time|decode time|total time)/i.test(x.trim())).join(' ').trim()}
    text=text.replace(/^\[[^\]]+\]\s*/gm,'').replace(/\s+/g,' ').trim();audit('voice_transcribed',{chars:text.length,language:lang});return {ok:true,text,language:lang,engine:'whisper.cpp'};
  }catch(e){audit('voice_transcribe_failed',{error:e.message});return {ok:false,error:e.message||String(e)}}
}
function r7ConfigureMediaPermissions(){
  try{
    session.defaultSession.setPermissionCheckHandler((_wc,permission,_origin,details)=> permission==='media' && (!details?.mediaType || details.mediaType==='audio'));
    session.defaultSession.setPermissionRequestHandler((wc,permission,callback,details)=>{const own=!mainWindow||wc===mainWindow.webContents;const audio=!details?.mediaTypes||details.mediaTypes.length===0||details.mediaTypes.includes('audio');callback(permission==='media'&&own&&audio)});
  }catch(e){audit('media_permission_setup_failed',{error:e.message})}
}

ipcMain.handle('qo:voice-engine-status',async()=>r7VoiceEngineStatus());
ipcMain.handle('qo:install-voice-engine',async()=>r7InstallVoiceEngine());
ipcMain.handle('qo:transcribe-wav',async(_e,p)=>r7TranscribeWav(p));
ipcMain.handle('qo:open-mic-settings',async()=>{try{if(process.platform==='win32')await shell.openExternal('ms-settings:privacy-microphone');return {ok:true}}catch(e){return {ok:false,error:e.message}}});
// --- /R7.0 Local Voice Engine ---

function createWindow(){
  mainWindow=new BrowserWindow({
    width:1480,height:920,minWidth:1020,minHeight:680,
    show:false,backgroundColor:'#f3f6fb',icon:path.join(__dirname,'renderer','assets','app.ico'),
    webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false,sandbox:false}
  });
  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadFile(path.join(__dirname,'renderer','index.html'));
  mainWindow.once('ready-to-show',()=>mainWindow.show());
  mainWindow.webContents.setWindowOpenHandler(({url})=>{shell.openExternal(url);return {action:'deny'}});
}

app.whenReady().then(()=>{ loadConfig(); r7ConfigureMediaPermissions(); createWindow(); app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow()}); });
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});

ipcMain.handle('qo:get-info', async()=>({
  appVersion:APP_VERSION, edition:EDITION, clientId:config.clientId, installId:config.installId, deviceName:os.hostname(),
  drivePath:config.drivePath||'', lastSyncAt:config.lastSyncAt||null,
  userData:app.getPath('userData'), exePath:process.execPath,
  localState: safeReadJson(localStatePath(),null)
}));

ipcMain.handle('qo:choose-drive', async()=>{
  const r=await dialog.showOpenDialog(mainWindow,{title:'Google Drive papkasini tanlang',properties:['openDirectory','createDirectory']});
  if(r.canceled||!r.filePaths[0]) return {ok:false};
  config.drivePath=r.filePaths[0]; saveConfig();
  ensureDir(driveRoot()); ensureDir(clientCloudDir()); ensureDir(ownerControlDir()); ensureDir(updateDir()); ensureDir(updateChannelDir('client')); ensureDir(updateChannelDir('owner')); ensureDir(path.join(driveRoot(),'catalog','images')); ensureUpdateLayout();
  audit('drive_configured',{path:config.drivePath});
  return {ok:true,path:config.drivePath};
});

ipcMain.handle('qo:connectivity', async(_e,opts={})=>{
  const internet=await internetCheck(!!opts.force); const control=readCloudControl();
  return {internet,driveConfigured:cloudConfigured(),driveReachable:cloudReachable(),drivePath:config.drivePath||'',lastSyncAt:config.lastSyncAt||null,clientId:config.clientId,license:control.license,update:control.update,updateChannels:{client:updateChannelStatus('client',false),owner:updateChannelStatus('owner',false),legacy:legacyUpdateStatus(false)}};
});
ipcMain.handle('qo:update-center', async(_e,opts={})=>updateCenterStatus(!!opts.verifyHash));
ipcMain.handle('qo:repair-update-layout', async()=>{
  if(!cloudReachable())return {ok:false,error:'Drive ulanmagan'};
  try{ensureUpdateLayout();return {ok:true,status:await updateCenterStatus(false)}}catch(e){return {ok:false,error:e.message}}
});
ipcMain.handle('qo:open-updates-folder', async()=>{
  if(!cloudReachable())return {ok:false,error:'Drive ulanmagan'};
  const dir=ensureDir(updateDir());const err=await shell.openPath(dir);return err?{ok:false,error:err}:{ok:true,path:dir};
});

ipcMain.handle('qo:save-state', async(_e,state)=>{
  try{persistLocalState(state);debounceCloudSync();return {ok:true};}catch(e){return {ok:false,error:e.message};}
});

ipcMain.handle('qo:sync-now', async(_e,state)=>{
  try{persistLocalState(state);const cloud=await writeCloudSnapshot(state);if(cloud)await scanImageLibrary();const control=readCloudControl();audit('manual_sync',{cloud});return {ok:true,cloud,control,lastSyncAt:config.lastSyncAt||null};}catch(e){return {ok:false,error:e.message};}
});

ipcMain.handle('qo:pull-snapshot', async()=>{
  if(!cloudReachable()) return {ok:false,error:'Google Drive ulanmagan'};
  const snap=safeReadJson(path.join(clientCloudDir(),'snapshot.json'),null);
  if(!snap?.state) return {ok:false,error:'Ushbu Client ID uchun snapshot topilmadi'};
  return {ok:true,state:snap.state,savedAt:snap.savedAt||null};
});

ipcMain.handle('qo:read-control', async()=>readCloudControl());
ipcMain.handle('qo:ack-commands', async(_e,ids)=>{clearProcessedCommands(ids||[]);return {ok:true}});

ipcMain.handle('qo:get-client-snapshot', async(_e,clientId)=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan'};
  const snap=safeReadJson(path.join(clientCloudDir(clientId),'snapshot.json'),null);
  if(!snap) return {ok:false,error:'Snapshot topilmadi'};
  return {ok:true,snapshot:snap};
});

ipcMain.handle('qo:list-clients', async()=>{
  if(!cloudReachable()) return {ok:false,error:'Google Drive papkasi ulanmagan',clients:[]};
  const root=ensureDir(path.join(driveRoot(),'clients')); const dirs=(await fsp.readdir(root,{withFileTypes:true})).filter(x=>x.isDirectory());
  const clients=dirs.map(d=>{const dir=path.join(root,d.name);return {clientId:d.name,heartbeat:safeReadJson(path.join(dir,'heartbeat.json'),{}),snapshot:safeReadJson(path.join(dir,'snapshot.json'),null)?true:false,license:safeReadJson(path.join(driveRoot(),'control',d.name,'license.json'),{status:'active'})};});
  return {ok:true,clients};
});

ipcMain.handle('qo:set-license', async(_e,payload)=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan'};
  const id=payload.clientId; const dir=ensureDir(path.join(driveRoot(),'control',id));
  atomicWriteJson(path.join(dir,'license.json'),{status:payload.status||'active',until:payload.until||null,note:payload.note||'',updatedAt:new Date().toISOString(),updatedBy:'owner-control'});
  audit('license_changed',{target:id,status:payload.status}); return {ok:true};
});

ipcMain.handle('qo:send-command', async(_e,payload)=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan'};
  const id=payload.clientId; const dir=ensureDir(path.join(driveRoot(),'control',id)); const f=path.join(dir,'commands.json'); const q=safeReadJson(f,{commands:[]})||{commands:[]};
  q.commands=q.commands||[]; q.commands.push({id:crypto.randomUUID(),command:payload.command,args:payload.args||{},createdAt:new Date().toISOString(),expiresAt:payload.expiresAt||null}); atomicWriteJson(f,q); audit('command_sent',{target:id,command:payload.command}); return {ok:true};
});

ipcMain.handle('qo:recovery-request', async(_e,payload)=>{
  const req={id:crypto.randomUUID(),clientId:config.clientId,email:payload.email||'',login:payload.login||'',requestedAt:new Date().toISOString(),device:os.hostname()};
  if(cloudReachable()){
    const d=ensureDir(path.join(driveRoot(),'recovery')); atomicWriteJson(path.join(d,req.id+'.json'),req);
  }
  audit('recovery_requested',{email:req.email});
  return {ok:true,mode:cloudReachable()?'drive':'local',requestId:req.id,message:cloudReachable()?'So‘rov QO Control Centerga yuborildi.':'Drive ulanmagan. Egasi lokal reset qilishi kerak.'};
});



ipcMain.handle('qo:list-recovery', async()=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan',requests:[]};
  const d=ensureDir(path.join(driveRoot(),'recovery'));
  const requests=fs.readdirSync(d,{withFileTypes:true}).filter(x=>x.isFile()&&x.name.endsWith('.json')).map(x=>safeReadJson(path.join(d,x.name),null)).filter(Boolean).sort((a,b)=>String(b.requestedAt||'').localeCompare(String(a.requestedAt||'')));
  return {ok:true,requests};
});
ipcMain.handle('qo:reply-recovery', async(_e,payload)=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan'};
  const d=ensureDir(path.join(driveRoot(),'recovery')), f=path.join(d,payload.requestId+'.json'), req=safeReadJson(f,null);
  if(!req) return {ok:false,error:'Recovery so‘rovi topilmadi'};
  let mailSent=false,mailError='';
  if(payload.emailEndpoint&&payload.to){
    try{
      const res=await fetch(payload.emailEndpoint,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({secret:payload.emailSecret||'',to:payload.to,subject:payload.subject||'Qurilish Ombori AI',body:payload.body||''})});
      const tx=await res.text(); mailSent=res.ok && !/error/i.test(tx);
      if(!mailSent)mailError=tx.slice(0,400);
    }catch(e){mailError=e.message}
  }
  req.status='answered';req.answeredAt=new Date().toISOString();req.mailSent=mailSent;req.mailError=mailError;atomicWriteJson(f,req);audit('recovery_answered',{requestId:req.id,mailSent});return {ok:true,mailSent,mailError};
});

ipcMain.handle('qo:image-library', async()=>{
  try{return {ok:true,items:await scanImageLibrary(),driveReachable:cloudReachable(),folder:cloudReachable()?catalogImageDir():imageCacheDir()};}
  catch(e){return {ok:false,error:e.message,items:[]};}
});
ipcMain.handle('qo:choose-product-image', async(_e,meta={})=>{
  try{return await importProductImage(meta);}catch(e){return {ok:false,error:e.message};}
});
ipcMain.handle('qo:open-image-folder', async()=>{
  try{const dir=cloudReachable()?catalogImageDir():imageCacheDir();ensureDir(dir);const err=await shell.openPath(dir);return err?{ok:false,error:err}:{ok:true,path:dir};}catch(e){return {ok:false,error:e.message};}
});

ipcMain.handle('qo:pick-update', async()=>{
  const r=await dialog.showOpenDialog(mainWindow,{title:'Update ZIP paketini tanlang',properties:['openFile'],filters:[{name:'ZIP update',extensions:['zip']}]});
  return r.canceled?{ok:false}:{ok:true,path:r.filePaths[0]};
});
ipcMain.handle('qo:publish-update', async(_e,p)=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan'};
  if(!p.packagePath||!fs.existsSync(p.packagePath)) return {ok:false,error:'Update fayli topilmadi'};
  const version=String(p.version||'').trim(); if(!version)return {ok:false,error:'Versiyani kiriting'};
  const target=normalizeUpdateTarget(p.target||'client'), publishedAt=new Date().toISOString();
  const source=await fsp.readFile(p.packagePath), hash=crypto.createHash('sha256').update(source).digest('hex');
  const publishOne=async(ch)=>{
    const dir=ensureDir(updateChannelDir(ch)), file=`qo-update-${version}.zip`, dest=path.join(dir,file);
    await fsp.writeFile(dest,source);
    const manifest={version,notes:p.notes||'',file,sha256:hash,publishedAt,channel:p.channel||'stable',target:ch,format:2};
    atomicWriteJson(path.join(dir,'manifest.json'),manifest); return {dir,dest,manifest};
  };
  let clientResult=null,ownerResult=null;
  if(target==='client'||target==='all')clientResult=await publishOne('client');
  if(target==='owner'||target==='all')ownerResult=await publishOne('owner');
  // Legacy CLIENT mirror: hozirgi 8.2.2 va eski Apps Script gatewaylar ishlashda davom etadi.
  if(clientResult){
    const legacyDir=ensureDir(updateDir()), legacyDest=path.join(legacyDir,clientResult.manifest.file);
    await fsp.writeFile(legacyDest,source);
    atomicWriteJson(path.join(legacyDir,'manifest.json'),{...clientResult.manifest,compatibilityMirror:true});
  }
  audit('update_published',{version,sha256:hash,target,channels:{client:!!clientResult,owner:!!ownerResult}});
  return {ok:true,sha256:hash,target,client:clientResult?{dest:clientResult.dest}:null,owner:ownerResult?{dest:ownerResult.dest}:null};
});

ipcMain.handle('qo:install-update', async()=>{
  if(!cloudReachable()) return {ok:false,error:'Drive ulanmagan'};
  const manifest=readUpdateManifest('owner'); if(!manifest) return {ok:false,error:'OWNER update manifest topilmadi'};
  const target=String(manifest.target||'owner').toLowerCase(); if(target!=='owner'&&target!=='all') return {ok:false,error:'Bu update OWNER uchun emas'};
  const zipPath=path.join(manifest._sourceDir||updateChannelDir('owner'),manifest.file); if(!fs.existsSync(zipPath)) return {ok:false,error:'OWNER update ZIP topilmadi'};
  const buf=await fsp.readFile(zipPath); const hash=crypto.createHash('sha256').update(buf).digest('hex'); if(hash!==manifest.sha256) return {ok:false,error:'Update SHA256 tekshiruvi muvaffaqiyatsiz'};
  const appPath=app.getAppPath(); const installRoot=path.dirname(path.dirname(appPath)); const tmp=path.join(app.getPath('temp'),'QOAI_UPDATE_'+Date.now()); ensureDir(tmp);
  const script=path.join(app.getPath('temp'),'qoai_apply_update_'+Date.now()+'.cmd');
  const content=`@echo off\r\nchcp 65001>nul\r\ntimeout /t 2 /nobreak>nul\r\nif exist "${tmp}" rmdir /s /q "${tmp}"\r\nmkdir "${tmp}"\r\npowershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${zipPath.replace(/'/g,"''")}' -DestinationPath '${tmp.replace(/'/g,"''")}' -Force"\r\nif errorlevel 1 exit /b 1\r\nxcopy /E /I /Y "${path.join(tmp,'app','*')}" "${appPath}\\" >nul\r\nstart "" "${process.execPath}"\r\n`;
  fs.writeFileSync(script,content,'utf8'); audit('update_install_requested',{version:manifest.version}); spawn('cmd.exe',['/c','start','',script],{detached:true,stdio:'ignore'}).unref(); setTimeout(()=>app.quit(),400); return {ok:true};
});

function tableToSpreadsheetML(title, headers, rows){
  const escXml=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const row=a=>`<Row>${a.map(v=>`<Cell><Data ss:Type="String">${escXml(v)}</Data></Cell>`).join('')}</Row>`;
  return `<?xml version="1.0"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"><Worksheet ss:Name="${escXml(title).slice(0,30)}"><Table>${row(headers)}${rows.map(row).join('')}</Table></Worksheet></Workbook>`;
}
function simpleDocHtml(title, headers, rows){
  const escH=s=>String(s??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return `<html><head><meta charset="utf-8"><style>body{font-family:Arial}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:6px;font-size:10pt}h1{font-size:18pt}</style></head><body><h1>${escH(title)}</h1><p>${new Date().toLocaleString()}</p><table><thead><tr>${headers.map(h=>`<th>${escH(h)}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(v=>`<td>${escH(v)}</td>`).join('')}</tr>`).join('')}</tbody></table></body></html>`;
}
async function saveExportFile(defaultName,filters,content,encoding='utf8'){
  const r=await dialog.showSaveDialog(mainWindow,{defaultPath:defaultName,filters}); if(r.canceled||!r.filePath)return {ok:false,canceled:true}; await fsp.writeFile(r.filePath,content,encoding); return {ok:true,path:r.filePath};
}
ipcMain.handle('qo:export', async(_e,p)=>{
  const title=p.title||'Qurilish Ombori AI'; const headers=p.headers||[]; const rows=p.rows||[];
  if(p.type==='excel') return saveExportFile((p.fileName||'hisobot')+'.xls',[{name:'Excel',extensions:['xls']}],tableToSpreadsheetML(title,headers,rows));
  if(p.type==='word') return saveExportFile((p.fileName||'hisobot')+'.doc',[{name:'Word',extensions:['doc']}],simpleDocHtml(title,headers,rows));
  if(p.type==='csv') {const q=v=>'"'+String(v??'').replace(/"/g,'""')+'"';return saveExportFile((p.fileName||'hisobot')+'.csv',[{name:'CSV',extensions:['csv']}],[headers,...rows].map(r=>r.map(q).join(',')).join('\r\n'));}
  if(p.type==='receipt') return saveExportFile((p.fileName||'chek')+'.txt',[{name:'Text receipt',extensions:['txt']}],p.text||'');
  if(p.type==='json') return saveExportFile((p.fileName||'backup')+'.json',[{name:'JSON',extensions:['json']}],JSON.stringify(p.data||{},null,2));
  if(p.type==='pdf'){
    const html=p.html||simpleDocHtml(title,headers,rows); const w=new BrowserWindow({show:false,webPreferences:{sandbox:true}}); await w.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html)); const pdf=await w.webContents.printToPDF({printBackground:true,pageSize:'A4'}); w.destroy(); return saveExportFile((p.fileName||'hisobot')+'.pdf',[{name:'PDF',extensions:['pdf']}],pdf,null);
  }
  return {ok:false,error:'Noma’lum export turi'};
});

ipcMain.handle('qo:create-backup', async(_e,state)=>{
  const payload={app:'Qurilish Ombori AI',version:APP_VERSION,createdAt:new Date().toISOString(),clientId:config.clientId,state};
  const r=await dialog.showSaveDialog(mainWindow,{defaultPath:`QOAI_backup_${new Date().toISOString().slice(0,10)}.json`,filters:[{name:'QO Backup',extensions:['json']}]});
  if(r.canceled||!r.filePath)return {ok:false}; atomicWriteJson(r.filePath,payload); return {ok:true,path:r.filePath};
});
ipcMain.handle('qo:restore-backup', async()=>{
  const r=await dialog.showOpenDialog(mainWindow,{properties:['openFile'],filters:[{name:'QO Backup',extensions:['json']}]}); if(r.canceled||!r.filePaths[0])return {ok:false}; const x=safeReadJson(r.filePaths[0],null); if(!x)return {ok:false,error:'Backup o‘qilmadi'}; return {ok:true,state:x.state||x};
});


ipcMain.handle('qo:set-service', async(_e,payload={})=>{
  config.serviceUrl=String(payload.url||'').trim(); config.serviceSecret=String(payload.secret||'').trim(); saveConfig(); audit('service_configured',{configured:serviceConfigured()});
  return {ok:true,configured:serviceConfigured(),clientId:config.clientId};
});
ipcMain.handle('qo:service-status', async(_e,opts={})=>{
  const internet=await internetCheck(!!opts.force); let service={ok:false,error:'QO Service ulanmagan'};
  if(internet&&serviceConfigured()) service=await servicePost('ping',{});
  return {internet,serviceConfigured:serviceConfigured(),serviceReachable:!!service.ok,serviceError:service.error||'',serviceUrl:config.serviceUrl||'',clientId:config.clientId,lastSyncAt:config.lastServiceSyncAt||null,license:service.license||config.lastLicense||{status:'active'},update:service.update||config.lastUpdate||null};
});
ipcMain.handle('qo:service-sync', async(_e,state)=>{
  try{persistLocalState(state);const r=await servicePost('sync',{state});if(r.ok){config.lastServiceSyncAt=new Date().toISOString();if(r.license)config.lastLicense=r.license;if(r.update)config.lastUpdate=r.update;saveConfig();}return {...r,lastSyncAt:config.lastServiceSyncAt||null};}catch(e){return {ok:false,error:e.message}}
});
ipcMain.handle('qo:service-control', async()=>servicePost('control',{}));
ipcMain.handle('qo:service-ack', async(_e,ids=[])=>servicePost('ack',{ids}));
ipcMain.handle('qo:service-recovery', async(_e,payload={})=>servicePost('recovery',payload));
ipcMain.handle('qo:service-ticket', async(_e,payload={})=>servicePost('support',payload));
ipcMain.handle('qo:service-install-update', async()=>{
  const meta=await servicePost('update_blob',{}); if(!meta.ok)return meta;
  try{
    const buf=Buffer.from(meta.base64||'','base64'); const hash=crypto.createHash('sha256').update(buf).digest('hex');
    if(meta.sha256 && hash!==meta.sha256) return {ok:false,error:'Update SHA-256 mos emas'};
    const zipPath=path.join(app.getPath('temp'),`qo-service-update-${meta.version||Date.now()}.zip`); await fsp.writeFile(zipPath,buf);
    const appPath=app.getAppPath(),tmp=path.join(app.getPath('temp'),'QOAI_SERVICE_UPDATE_'+Date.now()),script=path.join(app.getPath('temp'),'qoai_apply_service_update_'+Date.now()+'.cmd'); ensureDir(tmp);
    const content=`@echo off\r\nchcp 65001>nul\r\ntimeout /t 2 /nobreak>nul\r\nif exist "${tmp}" rmdir /s /q "${tmp}"\r\nmkdir "${tmp}"\r\npowershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${zipPath.replace(/'/g,"''")}' -DestinationPath '${tmp.replace(/'/g,"''")}' -Force"\r\nif errorlevel 1 exit /b 1\r\nxcopy /E /I /Y "${path.join(tmp,'app','*')}" "${appPath}\\" >nul\r\nstart "" "${process.execPath}"\r\n`;
    fs.writeFileSync(script,content,'utf8');audit('service_update_install_requested',{version:meta.version});spawn('cmd.exe',['/c','start','',script],{detached:true,stdio:'ignore'}).unref();setTimeout(()=>app.quit(),500);return {ok:true};
  }catch(e){return {ok:false,error:e.message}}
});


ipcMain.handle('qo:set-public-update-channel', async(_e,payload={})=>{
  const repo=parsePublicRepo(payload.repo||payload.repoUrl||''); if(!repo)return {ok:false,error:'GitHub repo linki noto‘g‘ri. Masalan: https://github.com/username/qo-updates'};
  config.publicUpdateRepo=repo.slug; config.publicUpdateBranch=String(payload.branch||'main').trim()||'main';
  if(Object.prototype.hasOwnProperty.call(payload,'token')&&String(payload.token||'').trim()) config.publicUpdateToken=String(payload.token).trim();
  saveConfig(); audit('public_update_channel_configured',{repo:repo.slug,branch:config.publicUpdateBranch,tokenConfigured:!!config.publicUpdateToken});
  return {ok:true,repo:repo.slug,repoUrl:repo.url,branch:config.publicUpdateBranch,tokenConfigured:!!config.publicUpdateToken};
});
ipcMain.handle('qo:public-update-config', async()=>{const r=publicRepo();return {ok:true,configured:!!r,repo:r?.slug||'',repoUrl:r?.url||'',branch:publicBranch(),tokenConfigured:!!config?.publicUpdateToken};});
ipcMain.handle('qo:public-update-status', async()=>({ok:true,configured:publicChannelConfigured(),publisherConfigured:publicPublisherConfigured(),repo:publicRepo()?.slug||'',repoUrl:publicRepo()?.url||'',branch:publicBranch(),client:await publicUpdateStatus('client'),owner:await publicUpdateStatus('owner'),checkedAt:new Date().toISOString()}));
ipcMain.handle('qo:publish-public-update', async(_e,p)=>publishPublicUpdate(p||{}));
ipcMain.handle('qo:install-public-update', async(_e,p={})=>downloadAndApplyPublicUpdate(String(p.target||'owner').toLowerCase()==='client'?'client':'owner'));

ipcMain.handle('qo:open-external',async(_e,url)=>{await shell.openExternal(url);return {ok:true}});
